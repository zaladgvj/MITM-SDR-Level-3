options:
  parameters:
    author: ''
    catch_exceptions: 'True'
    category: Custom
    cmake_opt: ''
    comment: ''
    copyright: ''
    description: Example of an OFDM receiver
    gen_cmake: 'On'
    gen_linking: dynamic
    generate_options: no_gui
    hier_block_src_path: '.:'
    id: rx_ofdm
    max_nouts: '0'
    output_language: python
    placement: (0,0)
    qt_qss_theme: ''
    realtime_scheduling: ''
    run: 'True'
    run_command: '{python} -u {filename}'
    run_options: prompt
    sizing_mode: fixed
    thread_safe_setters: ''
    title: OFDM Rx
    window_size: 1280, 1024
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [8, 12.0]
    rotation: 0
    state: enabled

blocks:
- name: fft_len
  id: variable
  parameters:
    comment: ''
    value: '64'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [328, 12.0]
    rotation: 0
    state: enabled
- name: header_equalizer
  id: variable
  parameters:
    comment: ''
    value: digital.ofdm_equalizer_simpledfe(fft_len, header_mod.base(), occupied_carriers,
      pilot_carriers, pilot_symbols)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [952, 76.0]
    rotation: 0
    state: enabled
- name: header_formatter
  id: variable
  parameters:
    comment: ''
    value: digital.packet_header_ofdm(occupied_carriers, n_syms=1, len_tag_key=packet_length_tag_key,
      frame_len_tag_key=length_tag_key, bits_per_header_sym=header_mod.bits_per_symbol(),
      bits_per_payload_sym=payload_mod.bits_per_symbol(), scramble_header=False)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [880, 12.0]
    rotation: 0
    state: enabled
- name: header_mod
  id: variable
  parameters:
    comment: ''
    value: digital.constellation_bpsk()
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [512, 12.0]
    rotation: 0
    state: enabled
- name: length_tag_key
  id: variable
  parameters:
    comment: ''
    value: '"frame_len"'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [392, 12.0]
    rotation: 0
    state: enabled
- name: occupied_carriers
  id: variable
  parameters:
    comment: ''
    value: (list(range(-26, -21)) + list(range(-20, -7)) + list(range(-6, 0)) + list(range(1,
      7)) + list(range(8, 21)) + list(range(22, 27)),)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [568, 76.0]
    rotation: 0
    state: enabled
- name: packet_len
  id: variable
  parameters:
    comment: ''
    value: '96'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1056, 12.0]
    rotation: 0
    state: enabled
- name: packet_length_tag_key
  id: variable
  parameters:
    comment: ''
    value: '"packet_len"'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1152, 12.0]
    rotation: 0
    state: enabled
- name: payload_equalizer
  id: variable
  parameters:
    comment: ''
    value: digital.ofdm_equalizer_simpledfe(fft_len, payload_mod.base(), occupied_carriers,
      pilot_carriers, pilot_symbols, 1)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1136, 76.0]
    rotation: 0
    state: enabled
- name: payload_mod
  id: variable
  parameters:
    comment: ''
    value: digital.constellation_qpsk()
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [688, 12.0]
    rotation: 0
    state: enabled
- name: pilot_carriers
  id: variable
  parameters:
    comment: ''
    value: ((-21, -7, 7, 21,),)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [720, 76.0]
    rotation: 0
    state: enabled
- name: pilot_symbols
  id: variable
  parameters:
    comment: ''
    value: ((1, 1, 1, -1,),)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [840, 76.0]
    rotation: 0
    state: enabled
- name: samp_rate
  id: variable
  parameters:
    comment: ''
    value: '10000'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [184, 76.0]
    rotation: 0
    state: enabled
- name: sync_word1
  id: variable
  parameters:
    comment: ''
    value: '[0., 0., 0., 0., 0., 0., 0., 1.41421356, 0., -1.41421356, 0., 1.41421356,
      0., -1.41421356, 0., -1.41421356, 0., -1.41421356, 0., 1.41421356, 0., -1.41421356,
      0., 1.41421356, 0., -1.41421356, 0., -1.41421356, 0., -1.41421356, 0., -1.41421356,
      0., 1.41421356, 0., -1.41421356, 0., 1.41421356, 0., 1.41421356, 0., 1.41421356,
      0., -1.41421356, 0., 1.41421356, 0., 1.41421356, 0., 1.41421356, 0., -1.41421356,
      0., 1.41421356, 0., 1.41421356, 0., 1.41421356, 0., 0., 0., 0., 0., 0.]'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [272, 76.0]
    rotation: 0
    state: enabled
- name: sync_word2
  id: variable
  parameters:
    comment: ''
    value: '[0j, 0j, 0j, 0j, 0j, 0j, (-1+0j), (-1+0j), (-1+0j), (-1+0j), (1+0j), (1+0j),
      (-1+0j), (-1+0j), (-1+0j), (1+0j), (-1+0j), (1+0j), (1+0j), (1 +0j), (1+0j),
      (1+0j), (-1+0j), (-1+0j), (-1+0j), (-1+0j), (-1+0j), (1+0j), (-1+0j), (-1+0j),
      (1+0j), (-1+0j), 0j, (1+0j), (-1+0j), (1+0j), (1+0j), (1+0j), (-1+0j), (1+0j),
      (1+0j), (1+0j), (-1+0j), (1+0j), (1+0j), (1+0j), (1+0j), (-1+0j), (1+0j), (-1+0j),
      (-1+0j), (-1+0j), (1+0j), (-1+0j), (1+0j), (-1+0j), (-1+0j), (-1+0j), (-1+0j),
      0j, 0j, 0j, 0j, 0j]'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [416, 76.0]
    rotation: 0
    state: enabled
- name: analog_frequency_modulator_fc_0
  id: analog_frequency_modulator_fc
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    maxoutbuf: '0'
    minoutbuf: '0'
    sensitivity: -2.0/fft_len
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [560, 164.0]
    rotation: 0
    state: enabled
- name: blocks_delay_0
  id: blocks_delay
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    delay: fft_len+fft_len//4
    maxoutbuf: '0'
    minoutbuf: '0'
    num_ports: '1'
    type: complex
    vlen: '1'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [328, 340.0]
    rotation: 0
    state: enabled
- name: blocks_file_sink_0
  id: blocks_file_sink
  parameters:
    affinity: ''
    alias: ''
    append: 'False'
    comment: ''
    file: /root/Desktop/reverse_shell.py
    type: byte
    unbuffered: 'False'
    vlen: '1'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1200, 788.0]
    rotation: 0
    state: true
- name: blocks_multiply_xx_0
  id: blocks_multiply_xx
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    maxoutbuf: '0'
    minoutbuf: '0'
    num_inputs: '2'
    type: complex
    vlen: '1'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [784, 168.0]
    rotation: 0
    state: enabled
- name: blocks_repack_bits_bb_0
  id: blocks_repack_bits_bb
  parameters:
    affinity: ''
    alias: ''
    align_output: 'True'
    comment: ''
    endianness: gr.GR_LSB_FIRST
    k: payload_mod.bits_per_symbol()
    l: '8'
    len_tag_key: packet_length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [552, 796.0]
    rotation: 0
    state: enabled
- name: digital_constellation_decoder_cb_0
  id: digital_constellation_decoder_cb
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    constellation: header_mod.base()
    maxoutbuf: '0'
    minoutbuf: '0'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1128, 404.0]
    rotation: 180
    state: enabled
- name: digital_constellation_decoder_cb_1
  id: digital_constellation_decoder_cb
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    constellation: payload_mod.base()
    maxoutbuf: '0'
    minoutbuf: '0'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [240, 804.0]
    rotation: 0
    state: enabled
- name: digital_crc32_bb_0
  id: digital_crc32_bb
  parameters:
    affinity: ''
    alias: ''
    check: 'True'
    comment: ''
    lengthtagname: packet_length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    packed: 'True'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [880, 788.0]
    rotation: 0
    state: enabled
- name: digital_header_payload_demux_0
  id: digital_header_payload_demux
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    guard_interval: fft_len//4
    header_len: '3'
    header_padding: '0'
    items_per_symbol: fft_len
    length_tag_key: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    output_symbols: 'True'
    samp_rate: samp_rate
    special_tags: ()
    timing_tag_key: '"rx_time"'
    trigger_tag_key: '""'
    type: complex
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [976, 164.0]
    rotation: 0
    state: enabled
- name: digital_ofdm_chanest_vcvc_0
  id: digital_ofdm_chanest_vcvc
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    eq_noise_red_len: '0'
    force_one_symbol: 'False'
    max_carr_offset: '3'
    maxoutbuf: '0'
    minoutbuf: '0'
    n_data_symbols: '1'
    sync_symbol1: sync_word1
    sync_symbol2: sync_word2
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [472, 476.0]
    rotation: 0
    state: enabled
- name: digital_ofdm_frame_equalizer_vcvc_0
  id: digital_ofdm_frame_equalizer_vcvc
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    cp_len: fft_len//4
    equalizer: header_equalizer.base()
    fft_len: fft_len
    fixed_frame_len: '1'
    len_tag_key: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    propagate_channel_state: 'True'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [808, 476.0]
    rotation: 0
    state: enabled
- name: digital_ofdm_frame_equalizer_vcvc_1
  id: digital_ofdm_frame_equalizer_vcvc
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    cp_len: fft_len//4
    equalizer: payload_equalizer.base()
    fft_len: fft_len
    fixed_frame_len: '0'
    len_tag_key: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    propagate_channel_state: 'True'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [568, 636.0]
    rotation: 0
    state: enabled
- name: digital_ofdm_serializer_vcc_header
  id: digital_ofdm_serializer_vcc
  parameters:
    affinity: ''
    alias: ''
    carr_offset_key: ''
    comment: ''
    fft_len: fft_len
    input_is_shifted: 'True'
    len_tag_key: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    occupied_carriers: occupied_carriers
    packet_len_tag_key: ''
    symbols_skipped: '0'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1120, 500.0]
    rotation: 0
    state: enabled
- name: digital_ofdm_serializer_vcc_payload
  id: digital_ofdm_serializer_vcc
  parameters:
    affinity: ''
    alias: ''
    carr_offset_key: ''
    comment: ''
    fft_len: fft_len
    input_is_shifted: 'True'
    len_tag_key: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    occupied_carriers: occupied_carriers
    packet_len_tag_key: packet_length_tag_key
    symbols_skipped: '1'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [872, 644.0]
    rotation: 0
    state: enabled
- name: digital_ofdm_sync_sc_cfb_0
  id: digital_ofdm_sync_sc_cfb
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    cp_len: fft_len//4
    fft_len: fft_len
    maxoutbuf: '0'
    minoutbuf: '0'
    threshold: '0.9'
    use_even_carriers: 'False'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [280, 220.0]
    rotation: 0
    state: enabled
- name: digital_packet_headerparser_b_0
  id: digital_packet_headerparser_b
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    header_formatter: header_formatter.base()
    maxoutbuf: '0'
    minoutbuf: '0'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [832, 404.0]
    rotation: 180
    state: enabled
- name: fft_vxx_0
  id: fft_vxx
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    fft_size: fft_len
    forward: 'True'
    maxoutbuf: '0'
    minoutbuf: '0'
    nthreads: '1'
    shift: 'True'
    type: complex
    window: ()
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [232, 476.0]
    rotation: 0
    state: enabled
- name: fft_vxx_1
  id: fft_vxx
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    fft_size: fft_len
    forward: 'True'
    maxoutbuf: '0'
    minoutbuf: '0'
    nthreads: '1'
    shift: 'True'
    type: complex
    window: ()
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [264, 620.0]
    rotation: 0
    state: enabled
- name: import_1
  id: import
  parameters:
    alias: ''
    comment: ''
    imports: from gnuradio.digital.utils import tagged_streams
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [184, 12.0]
    rotation: 0
    state: enabled
- name: limesdr_source_0
  id: limesdr_source
  parameters:
    affinity: ''
    alias: ''
    allow_tcxo_dac: '0'
    analog_bandw_ch0: 1.5e6
    analog_bandw_ch1: 1.5e6
    calibr_bandw_ch0: 2.5e6
    calibr_bandw_ch1: 2.5e6
    channel_mode: '0'
    comment: ''
    dacVal: '180'
    digital_bandw_ch0: samp_rate
    digital_bandw_ch1: samp_rate
    filename: ''
    gain_dB_ch0: '1'
    gain_dB_ch1: '1'
    lna_path_ch0: '255'
    lna_path_ch1: '2'
    maxoutbuf: '0'
    minoutbuf: '0'
    nco_freq_ch0: '0'
    nco_freq_ch1: '0'
    oversample: '0'
    rf_freq: 100e6
    samp_rate: samp_rate
    serial: ''
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [24, 236.0]
    rotation: 0
    state: true
- name: virtual_sink_0
  id: virtual_sink
  parameters:
    alias: ''
    comment: ''
    stream_id: Header Stream
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1392, 212.0]
    rotation: 0
    state: enabled
- name: virtual_sink_1
  id: virtual_sink
  parameters:
    alias: ''
    comment: ''
    stream_id: Payload Stream
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1392, 276.0]
    rotation: 0
    state: enabled
- name: virtual_sink_1_0
  id: virtual_sink
  parameters:
    alias: ''
    comment: ''
    stream_id: Payload IQ
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1208, 668.0]
    rotation: 0
    state: enabled
- name: virtual_source_0
  id: virtual_source
  parameters:
    alias: ''
    comment: ''
    stream_id: Header Stream
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [8, 508.0]
    rotation: 0
    state: enabled
- name: virtual_source_0_0
  id: virtual_source
  parameters:
    alias: ''
    comment: ''
    stream_id: Payload IQ
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [16, 804.0]
    rotation: 0
    state: enabled
- name: virtual_source_1
  id: virtual_source
  parameters:
    alias: ''
    comment: ''
    stream_id: Payload Stream
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [16, 644.0]
    rotation: 0
    state: enabled

connections:
- [analog_frequency_modulator_fc_0, '0', blocks_multiply_xx_0, '0']
- [blocks_delay_0, '0', blocks_multiply_xx_0, '1']
- [blocks_multiply_xx_0, '0', digital_header_payload_demux_0, '0']
- [blocks_repack_bits_bb_0, '0', digital_crc32_bb_0, '0']
- [digital_constellation_decoder_cb_0, '0', digital_packet_headerparser_b_0, '0']
- [digital_constellation_decoder_cb_1, '0', blocks_repack_bits_bb_0, '0']
- [digital_crc32_bb_0, '0', blocks_file_sink_0, '0']
- [digital_header_payload_demux_0, '0', virtual_sink_0, '0']
- [digital_header_payload_demux_0, '1', virtual_sink_1, '0']
- [digital_ofdm_chanest_vcvc_0, '0', digital_ofdm_frame_equalizer_vcvc_0, '0']
- [digital_ofdm_frame_equalizer_vcvc_0, '0', digital_ofdm_serializer_vcc_header, '0']
- [digital_ofdm_frame_equalizer_vcvc_1, '0', digital_ofdm_serializer_vcc_payload,
  '0']
- [digital_ofdm_serializer_vcc_header, '0', digital_constellation_decoder_cb_0, '0']
- [digital_ofdm_serializer_vcc_payload, '0', virtual_sink_1_0, '0']
- [digital_ofdm_sync_sc_cfb_0, '0', analog_frequency_modulator_fc_0, '0']
- [digital_ofdm_sync_sc_cfb_0, '1', digital_header_payload_demux_0, '1']
- [digital_packet_headerparser_b_0, header_data, digital_header_payload_demux_0, header_data]
- [fft_vxx_0, '0', digital_ofdm_chanest_vcvc_0, '0']
- [fft_vxx_1, '0', digital_ofdm_frame_equalizer_vcvc_1, '0']
- [limesdr_source_0, '0', blocks_delay_0, '0']
- [limesdr_source_0, '0', digital_ofdm_sync_sc_cfb_0, '0']
- [virtual_source_0, '0', fft_vxx_0, '0']
- [virtual_source_0_0, '0', digital_constellation_decoder_cb_1, '0']
- [virtual_source_1, '0', fft_vxx_1, '0']

metadata:
  file_format: 1
