options:
  parameters:
    author: ''
    catch_exceptions: 'True'
    category: Custom
    cmake_opt: ''
    comment: ''
    copyright: ''
    description: Example of an OFDM Transmitter
    gen_cmake: 'On'
    gen_linking: dynamic
    generate_options: qt_gui
    hier_block_src_path: '.:'
    id: tx_ofdm
    max_nouts: '0'
    output_language: python
    placement: (0,0)
    qt_qss_theme: ''
    realtime_scheduling: ''
    run: 'True'
    run_command: '{python} -u {filename}'
    run_options: run
    sizing_mode: fixed
    thread_safe_setters: ''
    title: OFDM Tx
    window_size: ''
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [16, 12.0]
    rotation: 0
    state: enabled

blocks:
- name: fft_len
  id: variable
  parameters:
    comment: ''
    value: '64'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [282, 16]
    rotation: 0
    state: enabled
- name: header_formatter
  id: variable
  parameters:
    comment: ''
    value: digital.packet_header_ofdm(occupied_carriers, n_syms=1, len_tag_key=length_tag_key,
      frame_len_tag_key=length_tag_key, bits_per_header_sym=header_mod.bits_per_symbol(),
      bits_per_payload_sym=payload_mod.bits_per_symbol(), scramble_header=False)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [989, 74]
    rotation: 0
    state: enabled
- name: header_mod
  id: variable
  parameters:
    comment: ''
    value: digital.constellation_bpsk()
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [666, 16]
    rotation: 0
    state: enabled
- name: length_tag_key
  id: variable
  parameters:
    comment: ''
    value: '"packet_len"'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [442, 16]
    rotation: 0
    state: enabled
- name: occupied_carriers
  id: variable
  parameters:
    comment: ''
    value: (list(range(-26, -21)) + list(range(-20, -7)) + list(range(-6, 0)) + list(range(1,
      7)) + list(range(8, 21)) + list(range(22, 27)),)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [584, 73]
    rotation: 0
    state: enabled
- name: packet_len
  id: variable
  parameters:
    comment: ''
    value: '96'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [570, 16]
    rotation: 0
    state: enabled
- name: payload_mod
  id: variable
  parameters:
    comment: ''
    value: digital.constellation_qpsk()
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [826, 16]
    rotation: 0
    state: enabled
- name: pilot_carriers
  id: variable
  parameters:
    comment: ''
    value: ((-21, -7, 7, 21,),)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [746, 72]
    rotation: 0
    state: enabled
- name: pilot_symbols
  id: variable
  parameters:
    comment: ''
    value: ((1, 1, 1, -1,),)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [874, 72]
    rotation: 0
    state: enabled
- name: rolloff
  id: variable
  parameters:
    comment: ''
    value: '0'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [986, 16]
    rotation: 0
    state: enabled
- name: samp_rate
  id: variable
  parameters:
    comment: ''
    value: '50000'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [346, 16]
    rotation: 0
    state: enabled
- name: sync_word1
  id: variable
  parameters:
    comment: ''
    value: '[0., 0., 0., 0., 0., 0., 0., 1.41421356, 0., -1.41421356, 0., 1.41421356,
      0., -1.41421356, 0., -1.41421356, 0., -1.41421356, 0., 1.41421356, 0., -1.41421356,
      0., 1.41421356, 0., -1.41421356, 0., -1.41421356, 0., -1.41421356, 0., -1.41421356,
      0., 1.41421356, 0., -1.41421356, 0., 1.41421356, 0., 1.41421356, 0., 1.41421356,
      0., -1.41421356, 0., 1.41421356, 0., 1.41421356, 0., 1.41421356, 0., -1.41421356,
      0., 1.41421356, 0., 1.41421356, 0., 1.41421356, 0., 0., 0., 0., 0., 0.]'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [282, 72]
    rotation: 0
    state: enabled
- name: sync_word2
  id: variable
  parameters:
    comment: ''
    value: '[0, 0, 0, 0, 0, 0, -1, -1, -1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, 1, 1,
      1, -1, -1, -1, -1, -1, 1, -1, -1, 1, -1, 0, 1, -1, 1, 1, 1, -1, 1, 1, 1, -1,
      1, 1, 1, 1, -1, 1, -1, -1, -1, 1, -1, 1, -1, -1, -1, -1, 0, 0, 0, 0, 0] '
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [410, 72]
    rotation: 0
    state: enabled
- name: blocks_file_source_0
  id: blocks_file_source
  parameters:
    affinity: ''
    alias: ''
    begin_tag: pmt.PMT_NIL
    comment: ''
    file: /root/Desktop/level 3/sample file/sdr level 3 final/reverse_shell.py
    length: '0'
    maxoutbuf: '0'
    minoutbuf: '0'
    offset: '0'
    repeat: 'True'
    type: byte
    vlen: '1'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [32, 164.0]
    rotation: 0
    state: true
- name: blocks_multiply_const_vxx_0
  id: blocks_multiply_const_vxx
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    const: '0.05'
    maxoutbuf: '0'
    minoutbuf: '0'
    type: complex
    vlen: '1'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [464, 644.0]
    rotation: 0
    state: enabled
- name: blocks_repack_bits_bb_0
  id: blocks_repack_bits_bb
  parameters:
    affinity: ''
    alias: ''
    align_output: 'False'
    comment: ''
    endianness: gr.GR_LSB_FIRST
    k: '8'
    l: payload_mod.bits_per_symbol()
    len_tag_key: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [912, 252.0]
    rotation: 0
    state: enabled
- name: blocks_stream_to_tagged_stream_0
  id: blocks_stream_to_tagged_stream
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    len_tag_key: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    packet_len: packet_len
    type: byte
    vlen: '1'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [360, 188.0]
    rotation: 0
    state: enabled
- name: blocks_tag_gate_0
  id: blocks_tag_gate
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    maxoutbuf: '0'
    minoutbuf: '0'
    propagate_tags: 'False'
    single_key: '""'
    type: complex
    vlen: '1'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [712, 636.0]
    rotation: 0
    state: enabled
- name: blocks_tagged_stream_mux_0
  id: blocks_tagged_stream_mux
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    lengthtagname: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    ninputs: '2'
    tag_preserve_head_pos: '0'
    type: complex
    vlen: '1'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [912, 352.0]
    rotation: 0
    state: enabled
- name: digital_chunks_to_symbols_xx_0
  id: digital_chunks_to_symbols_xx
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    dimension: '1'
    in_type: byte
    maxoutbuf: '0'
    minoutbuf: '0'
    num_ports: '1'
    out_type: complex
    symbol_table: header_mod.points()
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [472, 304.0]
    rotation: 0
    state: enabled
- name: digital_chunks_to_symbols_xx_0_0
  id: digital_chunks_to_symbols_xx
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    dimension: '1'
    in_type: byte
    maxoutbuf: '0'
    minoutbuf: '0'
    num_ports: '1'
    out_type: complex
    symbol_table: payload_mod.points()
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [456, 376.0]
    rotation: 0
    state: enabled
- name: digital_crc32_bb_0
  id: digital_crc32_bb
  parameters:
    affinity: ''
    alias: ''
    check: 'False'
    comment: ''
    lengthtagname: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    packed: 'True'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [632, 204.0]
    rotation: 0
    state: enabled
- name: digital_ofdm_carrier_allocator_cvc_0
  id: digital_ofdm_carrier_allocator_cvc
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    fft_len: fft_len
    len_tag_key: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
    occupied_carriers: occupied_carriers
    output_is_shifted: 'True'
    pilot_carriers: pilot_carriers
    pilot_symbols: pilot_symbols
    sync_words: (sync_word1, sync_word2)
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [368, 460.0]
    rotation: 0
    state: enabled
- name: digital_ofdm_cyclic_prefixer_0
  id: digital_ofdm_cyclic_prefixer
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    cp_len: fft_len//4
    input_size: fft_len
    maxoutbuf: '0'
    minoutbuf: '0'
    rolloff: rolloff
    tagname: length_tag_key
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [928, 484.0]
    rotation: 0
    state: enabled
- name: digital_packet_headergenerator_bb_0
  id: digital_packet_headergenerator_bb
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    header_formatter: header_formatter.base()
    len_tag_key: length_tag_key
    maxoutbuf: '0'
    minoutbuf: '0'
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [880, 180.0]
    rotation: 0
    state: enabled
- name: fft_vxx_0
  id: fft_vxx
  parameters:
    affinity: ''
    alias: ''
    comment: ''
    fft_size: fft_len
    forward: 'False'
    maxoutbuf: '0'
    minoutbuf: '0'
    nthreads: '1'
    shift: 'True'
    type: complex
    window: ()
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [624, 476.0]
    rotation: 0
    state: enabled
- name: header_bits
  id: virtual_sink
  parameters:
    alias: ''
    comment: ''
    stream_id: Header Bits
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1296, 188.0]
    rotation: 0
    state: enabled
- name: limesdr_sink_0
  id: limesdr_sink
  parameters:
    affinity: ''
    alias: ''
    allow_tcxo_dac: '0'
    analog_bandw_ch0: 5e6
    analog_bandw_ch1: 5e6
    calibr_bandw_ch0: 2.5e6
    calibr_bandw_ch1: 2.5e6
    channel_mode: '0'
    comment: ''
    dacVal: '180'
    digital_bandw_ch0: samp_rate
    digital_bandw_ch1: samp_rate
    filename: ''
    gain_dB_ch0: '1'
    gain_dB_ch1: '1'
    length_tag_name: ''
    nco_freq_ch0: '0'
    nco_freq_ch1: '0'
    oversample: '0'
    pa_path_ch0: '255'
    pa_path_ch1: '255'
    rf_freq: 100e6
    samp_rate: samp_rate
    serial: ''
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1032, 620.0]
    rotation: 0
    state: true
- name: virtual_sink_0
  id: virtual_sink
  parameters:
    alias: ''
    comment: ''
    stream_id: Time Domain
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1304, 500.0]
    rotation: 0
    state: enabled
- name: virtual_sink_0_0
  id: virtual_sink
  parameters:
    alias: ''
    comment: ''
    stream_id: Payload Bits
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1296, 268.0]
    rotation: 0
    state: enabled
- name: virtual_sink_0_0_0
  id: virtual_sink
  parameters:
    alias: ''
    comment: ''
    stream_id: Pre-OFDM
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [1304, 372.0]
    rotation: 0
    state: enabled
- name: virtual_source_0
  id: virtual_source
  parameters:
    alias: ''
    comment: ''
    stream_id: Header Bits
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [40, 300.0]
    rotation: 0
    state: enabled
- name: virtual_source_0_0
  id: virtual_source
  parameters:
    alias: ''
    comment: ''
    stream_id: Payload Bits
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [32, 372.0]
    rotation: 0
    state: enabled
- name: virtual_source_0_0_0
  id: virtual_source
  parameters:
    alias: ''
    comment: ''
    stream_id: Pre-OFDM
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [32, 508.0]
    rotation: 0
    state: enabled
- name: virtual_source_0_0_0_0
  id: virtual_source
  parameters:
    alias: ''
    comment: ''
    stream_id: Time Domain
  states:
    bus_sink: false
    bus_source: false
    bus_structure: null
    coordinate: [32, 644.0]
    rotation: 0
    state: enabled

connections:
- [blocks_file_source_0, '0', blocks_stream_to_tagged_stream_0, '0']
- [blocks_multiply_const_vxx_0, '0', blocks_tag_gate_0, '0']
- [blocks_repack_bits_bb_0, '0', virtual_sink_0_0, '0']
- [blocks_stream_to_tagged_stream_0, '0', digital_crc32_bb_0, '0']
- [blocks_tag_gate_0, '0', limesdr_sink_0, '0']
- [blocks_tagged_stream_mux_0, '0', virtual_sink_0_0_0, '0']
- [digital_chunks_to_symbols_xx_0, '0', blocks_tagged_stream_mux_0, '0']
- [digital_chunks_to_symbols_xx_0_0, '0', blocks_tagged_stream_mux_0, '1']
- [digital_crc32_bb_0, '0', blocks_repack_bits_bb_0, '0']
- [digital_crc32_bb_0, '0', digital_packet_headergenerator_bb_0, '0']
- [digital_ofdm_carrier_allocator_cvc_0, '0', fft_vxx_0, '0']
- [digital_ofdm_cyclic_prefixer_0, '0', virtual_sink_0, '0']
- [digital_packet_headergenerator_bb_0, '0', header_bits, '0']
- [fft_vxx_0, '0', digital_ofdm_cyclic_prefixer_0, '0']
- [virtual_source_0, '0', digital_chunks_to_symbols_xx_0, '0']
- [virtual_source_0_0, '0', digital_chunks_to_symbols_xx_0_0, '0']
- [virtual_source_0_0_0, '0', digital_ofdm_carrier_allocator_cvc_0, '0']
- [virtual_source_0_0_0_0, '0', blocks_multiply_const_vxx_0, '0']

metadata:
  file_format: 1
